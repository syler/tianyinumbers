### Clear markup

Reset and base path generator for local-static markup ( lessjs + native html + native js ( + jquery included ) )