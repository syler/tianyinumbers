# Simple jquery switcher

for call:

    $(function() {
      $(".js__switcher, .js__another_switcher").switcher();
    });

[Demo](http://jumanji.name/example/jquery-switcher/)